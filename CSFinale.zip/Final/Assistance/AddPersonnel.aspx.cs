﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Assistance_AddPersonnel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }






    protected void Button1_Click(object sender, EventArgs e)
    {
        string filename = Path.GetFileName(fluPersonnelPic.PostedFile.FileName);
        using (Stream fs = fluPersonnelPic.PostedFile.InputStream)
        {
            using (BinaryReader br = new BinaryReader(fs))
            {
                byte[] PersonnelPic = br.ReadBytes((Int32)fs.Length);
                try {
                    using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("spInsertPersonnel", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        //SqlCommand cmd = new SqlCommand("INSERT INTO Personnel VALUES(" + txtNeme.Text + ", " + txtSurname.Text + ", " + txtContact.Text +
                        //    ", " + PersonnelPic + ", " + ddlSpeciality.SelectedValue + ", " + ddlType.SelectedValue + ")", conn);
                        cmd.Parameters.AddWithValue("@Personnel_Name", txtNeme.Text);
                        cmd.Parameters.AddWithValue("@Personnel_Surname", txtSurname.Text);
                        cmd.Parameters.AddWithValue("@Personnel_Contact", txtContact.Text);
                        cmd.Parameters.AddWithValue("@Personnel_Picture", PersonnelPic);
                        cmd.Parameters.AddWithValue("@Speciality_ID", ddlSpeciality.SelectedValue);
                        cmd.Parameters.AddWithValue("@Personnel_Type_ID", ddlType.SelectedValue);
                        cmd.ExecuteNonQuery();
                        conn.Close();

                        txtContact.Text = "";
                        txtNeme.Text = "";
                        txtSurname.Text = "";
                        lblResponse.Text = "Success!";
                        txtNeme.Focus();
                    }
                }
        catch (Exception)
                {

                    lblResponse.Text = "Failed!";
                }

            }

        }
    }
    protected void txtImage_Init(object sender, EventArgs e)
    {
       
    }
}