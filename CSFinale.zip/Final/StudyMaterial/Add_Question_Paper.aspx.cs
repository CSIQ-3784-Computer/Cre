﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudyMaterial_Add_Question_Paper : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string filename = Path.GetFileName(fluFile.PostedFile.FileName);
        string contentType = fluFile.PostedFile.ContentType.ToString();
        using (Stream fs = fluFile.PostedFile.InputStream)
        {
            using (BinaryReader br = new BinaryReader(fs))
            {
                byte[] QuestionPaperFile = br.ReadBytes((Int32)fs.Length);
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {

                    conn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO [Question_Paper] VALUES (@Paper_Year,@Paper_Extension, @Paper_Test_Num, @File, @Student_ID, @Module_Code, @Module_Name)", conn);
                    cmd.Parameters.AddWithValue("@Paper_Year", txtYear.Text);
                    cmd.Parameters.AddWithValue("@Paper_Extension", contentType);
                    cmd.Parameters.AddWithValue("@Paper_Test_Num", txtNum.Text);
                    cmd.Parameters.AddWithValue("@File", QuestionPaperFile);
                    cmd.Parameters.AddWithValue("@Student_ID", ddlStud.SelectedValue);
                    cmd.Parameters.AddWithValue("@Module_Code", txtModule_Code.Text);
                    cmd.Parameters.AddWithValue("@Module_Name", txtModule_Name.Text);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        Response.Redirect("~/StudyMaterial/Add_Question_Paper.aspx");
    }
}