﻿function readURL(fluNotesFile) {
    if (fluNotesFile.files && fluNotesFile.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imgPersonnelPic').attr('src', e.target.result);
        }

        reader.readAsDataURL(fluNotesFile.files[0]);
    }
}