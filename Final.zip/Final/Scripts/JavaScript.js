﻿function readURL(FileUpload1) {
    if (FileUpload1.files && FileUpload1.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imgPersonnelPic').attr('src', e.target.result);
        }

        reader.readAsDataURL(FileUpload1.files[0]);
    }
}