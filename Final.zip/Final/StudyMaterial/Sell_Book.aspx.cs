﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudyMaterial_Add_Question_Paper : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnAddBook_Click(object sender, EventArgs e)
    {

        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
        {

            conn.Open();
            string filename = Path.GetFileName(fluBookPic.FileName);
            SqlCommand cmd = new SqlCommand("insert into Book values(@Book_Price, @Book_Defects ,@Book_ISBN, @Book_Edition, @Book_Picture, @Book_Name, @Student_ID, @Module_Code, @Module_Name) ", conn);
            cmd.Parameters.AddWithValue("@Book_Price", txtPrice.Text);
            cmd.Parameters.AddWithValue("@Book_Defects", txtDefects.Text);
            cmd.Parameters.AddWithValue("@Book_ISBN", txtISBN.Text);
            cmd.Parameters.AddWithValue("@Book_Edition", txtEdition.Text);
            cmd.Parameters.AddWithValue("@Book_Picture", fluBookPic.FileContent);
            cmd.Parameters.AddWithValue("@Book_Name", txtTitle.Text);
            cmd.Parameters.AddWithValue("@Student_ID", ddlStudent.SelectedValue);
            cmd.Parameters.AddWithValue("@Module_Code", txtMCode.Text);
            cmd.Parameters.AddWithValue("@Module_Name", txtMName.Text);

            cmd.ExecuteNonQuery();
        }
        Response.Redirect("~/StudyMaterial/Books.aspx");
    }
}