﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudyMaterial_Add_Question_Paper : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/StudyMaterial/Add_Notes.aspx");
    }

    protected void DetailsView1_ItemInserting(object sender, DetailsViewInsertEventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
        {
            string filename = Path.GetFileName(FileUpload1.FileName);
            SqlCommand cmd = new SqlCommand("INSERT INTO [Note] ([Notes_Date], [Notes_Extension], [Notes_Topic], [Notes_File], [Student_ID], [Module_Code], [Module_Name]) VALUES (@Notes_Date, @Notes_Extension, @Notes_Topic, @Notes_File, @Student_ID, @Module_Code, @Module_Name)", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Notes_Date", txtNeme.Text);
            cmd.Parameters.AddWithValue("@Personnel_Surname", txtSurname.Text);
            cmd.Parameters.AddWithValue("@Personnel_Contact", txtContact.Text);
            cmd.Parameters.AddWithValue("@Speciality_Name", speciality);
            cmd.Parameters.AddWithValue("@Personnel_Type_Name", type);
            cmd.Parameters.AddWithValue("@Personnel_Picture", FileUpload1.FileContent);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

    }
}