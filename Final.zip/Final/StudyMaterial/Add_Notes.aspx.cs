﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudyMaterial_Add_Question_Paper : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
        string contentType = FileUpload1.PostedFile.ContentType.ToString();
        using (Stream fs = FileUpload1.PostedFile.InputStream)
        {
            using (BinaryReader br = new BinaryReader(fs))
            {
                byte[] NotesFile = br.ReadBytes((Int32)fs.Length);
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("spInsertNotes",conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Notes_Date",Convert.ToDateTime(txtDate.Text));
                    cmd.Parameters.AddWithValue("@Notes_Extension", contentType);
                    cmd.Parameters.AddWithValue("@Notes_Topic", filename);
                    cmd.Parameters.AddWithValue("@Notes_File", NotesFile);
                    cmd.Parameters.AddWithValue("@Student_ID", DropDownList1.SelectedValue);
                    cmd.Parameters.AddWithValue("@Module_Code", txtMCode.Text);
                    cmd.Parameters.AddWithValue("@Module_Name", txtMName.Text);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
        Response.Redirect("~/StudyMaterial/Notes.aspx");
    }



    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtDate.Text = Calendar1.SelectedDate.Date.ToLongDateString();
    }
}