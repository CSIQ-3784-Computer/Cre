﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

public partial class SendEmail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtbxTo.Text = "mohlaphodimaxo@gmail.com";
    }
    protected void btnSend_Click(object sender, EventArgs e)
    {
        try
        {
            //class that takes care of sending of a message
            MailMessage message = new MailMessage(txtbxFrom.Text, txtbxTo.Text, ddlSubject.SelectedValue, txtbxBody.Text);
            message.IsBodyHtml = true;

            //determines the domain for email e.i this one is for gmail,hopes it works with ufs
            //this is to say only ufs email can be able to send
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.Credentials = new System.Net.NetworkCredential("mohlaphodimaxo@gmail.com", "2010143895");
            client.Send(message);
            lblStaus.Text = "Mail was sent successfully";
        }
        catch (Exception ex)
        {
            lblStaus.Text = ex.StackTrace;
        }
    }
}