﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Assistance_AddPersonnel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }






    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            string speciality = ddlSpeciality.SelectedValue;
            string type = ddlType.SelectedValue;
            conn.Open();
            string filename = Path.GetFileName(FileUpload1.FileName);
            SqlCommand cmd = new SqlCommand("insert into Personnel values(", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Personnel_Name", txtNeme.Text);
            cmd.Parameters.AddWithValue("@Personnel_Surname", txtSurname.Text);
            cmd.Parameters.AddWithValue("@Personnel_Contact", txtContact.Text);
            cmd.Parameters.AddWithValue("@Speciality_Name", speciality);
            cmd.Parameters.AddWithValue("@Personnel_Type_Name", type);
            cmd.Parameters.AddWithValue("@Personnel_Picture", FileUpload1.FileContent);
            cmd.ExecuteNonQuery();
            conn.Close();

            txtContact.Text = "";
            txtNeme.Text = "";
            txtSurname.Text = "";
            lblResponse.Text = "Success!";

        }
        catch (Exception)
        {

            lblResponse.Text = "Failed!";
        }
        


    }

    protected void txtImage_Init(object sender, EventArgs e)
    {
       
    }
}